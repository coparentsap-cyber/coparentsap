B// netlify/functions/send-notification.cjs
const nodemailer = require('nodemailer');

exports.handler = async (event, context) => {
  try {
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      auth: {
        user: process.env.GMAIL_USER,
        pass: process.env.GMAIL_APP_PASSWORD,
      },
    });

    const info = await transporter.sendMail({
      from: `"Co-Parents" <${process.env.GMAIL_USER}>`,
      to: 'jeremygomespr@gmail.com',
      subject: 'Notification Co-Parents ✅',
      text: 'Bonjour, ceci est un test automatique depuis Netlify',
      html: '<p>Bonjour, ceci est un test automatique depuis Netlify ✅</p>',
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Email envoyé', id: info.messageId }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message }),
    };
  }
};

